<?php
/**
 * Created by PhpStorm.
 * User: Umesh Kumar Yadav
 * Date: 12/2/2017
 * Time: 1:19 PM
 */
return [
    'image_dimensions' => [
        'book' => [
            'main_image' => [
                [
                    'width' => 230,
                    'height' => 230
                ],
            ],
        ],

    ],
    'pagination_limit' => [
        'blog_list' => 1,
        'blog_category' => 1,
    ],
];