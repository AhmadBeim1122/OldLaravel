<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FoodItemFoodSchedule extends Model
{
    //food_item_food_schedule
}
